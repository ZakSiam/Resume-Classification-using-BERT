# Importing all the required packages or libraries
import os
import sys
import pandas as pd
from transformers import BertTokenizer, BertForSequenceClassification
from pdfminer.high_level import extract_text
import torch
from shutil import copyfile
import warnings

warnings.filterwarnings('ignore')  # Suppressing all the warnings

MODEL_PATH = './BERT Results/saved_model'  # Path to the saved best BERT model
CATEGORIES_PATH = './categories_mapping.csv'  # Path to the categories_mapping.csv file 

# Loading the mapping of categories 
CATEGORIES = pd.read_csv(CATEGORIES_PATH, squeeze=True).values

# Loading the model
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertForSequenceClassification.from_pretrained(MODEL_PATH)
model.eval()

# Getting the input directory from the command line argument
input_dir = sys.argv[1]

# Creation of DataFrame to store the results
result_df = pd.DataFrame(columns=['filename', 'category'])

# Iterate through all the PDF files inside the input directory
for filename in os.listdir(input_dir):
    filepath = os.path.join(input_dir, filename)

    if filename.endswith(".pdf"):
        # Reading the PDF content using the pdfminer.six library
        text = extract_text(filepath)

        # Tokenization and classification of the text
        inputs = tokenizer(text, padding='max_length', truncation=True, return_tensors="pt")
        with torch.no_grad():
            outputs = model(**inputs)
            predicted_label = torch.argmax(outputs.logits[0]).item()

        # Getting the corresponding category
        category = CATEGORIES[predicted_label]

        # Creating the category folder if it does not exist
        category_folder = os.path.join(input_dir, category)
        if not os.path.exists(category_folder):
            os.makedirs(category_folder)

        # Moving the file to its category folder
        new_filepath = os.path.join(category_folder, filename)
        copyfile(filepath, new_filepath)
        os.remove(filepath)

        # Adding to the result DataFrame
        result_df = result_df.append({'filename': filename, 'category': category}, ignore_index=True)

# Saving all the results to a CSV file named categorized_resumes.csv
result_df.to_csv(os.path.join(input_dir, 'categorized_resumes.csv'), index=False)

print("Resumes have been categorized and saved successfully.")
